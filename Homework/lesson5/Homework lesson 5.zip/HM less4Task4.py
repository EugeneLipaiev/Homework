name = str(input("Print name"))
name_1 = "eugene"

if name.lower() == name_1:
    print(True)
if name.lower() != name_1:
    print(False)

