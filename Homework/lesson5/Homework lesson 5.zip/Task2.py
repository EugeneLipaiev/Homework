name = input("Write your name"))
age = int(input("Age"))
print(f"Hello {name}, next birthday you will be {age+1}")
